Description of disposable import into mantis.

See ../readme.libs for summary of all libraries

Removed:

Added:
	readme_mantis.txt - this file ;-)
	index.html - prevent directory browsing on misconfigured servers

Changes:
	- Move all contents of data folder to root.
	- Move all contents of php folder to root.
	- Delete tests folder.
	- Changed disposable.php _loadfile() to load data files from same folder.

